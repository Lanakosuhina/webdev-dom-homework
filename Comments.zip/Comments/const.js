
export let nameInput = document.querySelector(".add-form-name");
export let commentInput = document.querySelector(".add-form-text");
export let addButton = document.querySelector(".add-form-button");
export const addLoader = document.querySelector(".mask");
export const appElement = document.getElementById("app");